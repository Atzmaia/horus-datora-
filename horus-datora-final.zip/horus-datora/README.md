# Horus Datora

Painel público de gerenciamento de credenciais com design baseado no Olho de Horus e efeitos visuais profissionais.

## Características

- 🎨 **Design Temático**: Wallpaper com Olho de Horus com efeitos visuais
- 🔍 **Busca e Filtros**: Consulte credenciais por login ou arquivo
- 📊 **Tabela Interativa**: Visualização paginada de credenciais
- 📥 **Exportação**: Exporte dados em CSV
- ✨ **Efeitos Visuais**: Partículas flutuantes e animações suaves
- 📱 **Responsivo**: Funciona perfeitamente em dispositivos móveis

## Tecnologias

- React 19
- TypeScript
- Vite
- Lucide React Icons

## Instalação

```bash
npm install
# ou
pnpm install
```

## Desenvolvimento

```bash
npm run dev
# ou
pnpm dev
```

O site abrirá em `http://localhost:5173`

## Build

```bash
npm run build
# ou
pnpm build
```

## Estrutura

```
src/
├── components/
│   ├── HorusBackground.tsx      # Wallpaper com Olho de Horus
│   ├── HorusBackground.css
│   ├── CredentialsPanel.tsx     # Painel de credenciais
│   ├── CredentialsPanel.css
│   ├── ParticleEffect.tsx       # Efeito de partículas
│   └── ParticleEffect.css
├── App.tsx                       # Componente principal
├── App.css
├── main.tsx
└── index.css                     # Estilos globais
```

## Uso

1. Abra o site em seu navegador
2. Use a barra de busca para procurar credenciais
3. Filtre por arquivo usando o dropdown
4. Clique no ícone de olho para visualizar detalhes
5. Use o botão "Exportar" para baixar os dados em CSV

## Licença

Todos os direitos reservados © 2026 Horus Datora

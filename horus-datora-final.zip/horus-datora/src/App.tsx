import { useState, useEffect } from 'react'
import HorusBackground from './components/HorusBackground'
import CredentialsPanel from './components/CredentialsPanel'
import ParticleEffect from './components/ParticleEffect'
import './App.css'

function App() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="app-container">
      <HorusBackground />
      <ParticleEffect />
      
      <div className="app-content">
        <header className="app-header">
          <div className="header-content">
            <h1 className="title">HORUS DATORA</h1>
            <p className="subtitle">Gerenciamento de Credenciais</p>
          </div>
        </header>

        <main className="app-main">
          {mounted && <CredentialsPanel />}
        </main>

        <footer className="app-footer">
          <p>&copy; 2026 Horus Datora. Todos os direitos reservados.</p>
        </footer>
      </div>
    </div>
  )
}

export default App

import { useEffect, useRef } from 'react'
import './ParticleEffect.css'

export default function ParticleEffect() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const createParticle = () => {
      const particle = document.createElement('div')
      particle.className = 'particle'
      
      const size = Math.random() * 4 + 2
      const duration = Math.random() * 3 + 2
      const delay = Math.random() * 2
      const xPos = Math.random() * 100
      
      particle.style.width = size + 'px'
      particle.style.height = size + 'px'
      particle.style.left = xPos + '%'
      particle.style.animation = `particle-float ${duration}s linear ${delay}s infinite`
      
      containerRef.current?.appendChild(particle)
      
      setTimeout(() => {
        particle.remove()
      }, (duration + delay) * 1000)
    }

    const interval = setInterval(() => {
      createParticle()
    }, 300)

    return () => clearInterval(interval)
  }, [])

  return <div ref={containerRef} className="particle-container"></div>
}

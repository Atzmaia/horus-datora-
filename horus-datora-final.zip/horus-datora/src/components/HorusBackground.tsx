import './HorusBackground.css'

export default function HorusBackground() {
  return (
    <div className="horus-background">
      {/* Camada de fundo com gradiente radial */}
      <div className="gradient-layer"></div>

      {/* Camada de padrão */}
      <div className="pattern-layer"></div>

      {/* SVG do Olho de Horus - Versão Elaborada */}
      <svg
        className="horus-eye-main"
        viewBox="0 0 300 300"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Gradientes */}
          <radialGradient id="goldGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#f4d03f" />
            <stop offset="50%" stopColor="#d4af37" />
            <stop offset="100%" stopColor="#8b7500" />
          </radialGradient>

          <linearGradient id="eyeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#d4af37" />
            <stop offset="50%" stopColor="#f4d03f" />
            <stop offset="100%" stopColor="#d4af37" />
          </linearGradient>

          <filter id="glow">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="innerShadow">
            <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="blur" />
            <feOffset in="blur" dx="0" dy="2" result="offset" />
            <feFlood floodColor="#000000" floodOpacity="0.5" result="color" />
            <feComposite in="color" in2="offset" operator="in" result="shadow" />
            <feComposite in="shadow" in2="SourceAlpha" operator="in" result="shadow" />
            <feComposite in="SourceGraphic" in2="shadow" operator="arithmetic" k1="0" k2="1" k3="1" k4="0" />
          </filter>
        </defs>

        {/* Camadas de aura */}
        <circle cx="150" cy="150" r="140" fill="none" stroke="url(#goldGradient)" strokeWidth="2" opacity="0.15" />
        <circle cx="150" cy="150" r="130" fill="none" stroke="url(#goldGradient)" strokeWidth="1" opacity="0.1" />
        <circle cx="150" cy="150" r="120" fill="none" stroke="url(#goldGradient)" strokeWidth="1" opacity="0.08" />

        {/* Olho externo - Contorno */}
        <ellipse cx="150" cy="150" rx="100" ry="110" fill="none" stroke="url(#eyeGradient)" strokeWidth="3" opacity="0.6" filter="url(#glow)" />

        {/* Olho externo - Preenchimento suave */}
        <ellipse cx="150" cy="150" rx="100" ry="110" fill="url(#goldGradient)" opacity="0.08" />

        {/* Sobrancelha superior */}
        <path d="M 70 80 Q 150 20 230 80" stroke="url(#eyeGradient)" strokeWidth="4" fill="none" opacity="0.5" strokeLinecap="round" />

        {/* Sobrancelha inferior */}
        <path d="M 70 220 Q 150 280 230 220" stroke="url(#eyeGradient)" strokeWidth="4" fill="none" opacity="0.5" strokeLinecap="round" />

        {/* Lágrima superior */}
        <path d="M 150 40 Q 145 70 140 100" stroke="url(#eyeGradient)" strokeWidth="2" fill="none" opacity="0.4" />

        {/* Lágrima inferior */}
        <path d="M 150 260 Q 155 230 160 200" stroke="url(#eyeGradient)" strokeWidth="2" fill="none" opacity="0.4" />

        {/* Íris - Camada externa */}
        <circle cx="150" cy="150" r="65" fill="none" stroke="url(#eyeGradient)" strokeWidth="2" opacity="0.5" />

        {/* Íris - Padrão radial */}
        <g opacity="0.3">
          <line x1="150" y1="85" x2="150" y2="65" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="150" y1="235" x2="150" y2="215" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="85" y1="150" x2="65" y2="150" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="235" y1="150" x2="215" y2="150" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="110" y1="110" x2="95" y2="95" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="190" y1="190" x2="205" y2="205" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="190" y1="110" x2="205" y2="95" stroke="url(#eyeGradient)" strokeWidth="1" />
          <line x1="110" y1="190" x2="95" y2="205" stroke="url(#eyeGradient)" strokeWidth="1" />
        </g>

        {/* Pupila - Camada externa */}
        <circle cx="150" cy="150" r="45" fill="none" stroke="url(#eyeGradient)" strokeWidth="2" opacity="0.6" filter="url(#glow)" />

        {/* Pupila - Preenchimento */}
        <circle cx="150" cy="150" r="45" fill="url(#goldGradient)" opacity="0.25" />

        {/* Pupila - Núcleo escuro */}
        <circle cx="150" cy="150" r="35" fill="#1a1a2e" opacity="0.8" />

        {/* Brilho principal */}
        <circle cx="140" cy="140" r="18" fill="url(#goldGradient)" opacity="0.9" filter="url(#glow)" />

        {/* Brilho secundário */}
        <circle cx="138" cy="138" r="10" fill="#f4d03f" opacity="0.7" />

        {/* Brilho terciário */}
        <circle cx="136" cy="136" r="5" fill="#ffffff" opacity="0.6" />

        {/* Reflexo na pupila */}
        <circle cx="160" cy="160" r="8" fill="url(#goldGradient)" opacity="0.4" />

        {/* Linhas de energia radiais */}
        <g opacity="0.2" strokeWidth="1" stroke="url(#eyeGradient)">
          <line x1="150" y1="0" x2="150" y2="40" />
          <line x1="150" y1="260" x2="150" y2="300" />
          <line x1="0" y1="150" x2="40" y2="150" />
          <line x1="260" y1="150" x2="300" y2="150" />
          <line x1="40" y1="40" x2="70" y2="70" />
          <line x1="230" y1="230" x2="260" y2="260" />
          <line x1="260" y1="40" x2="230" y2="70" />
          <line x1="70" y1="230" x2="40" y2="260" />
        </g>

        {/* Símbolos egípcios ao redor */}
        <text x="150" y="30" textAnchor="middle" fontSize="20" fill="url(#goldGradient)" opacity="0.4" fontFamily="serif">☥</text>
        <text x="150" y="280" textAnchor="middle" fontSize="20" fill="url(#goldGradient)" opacity="0.4" fontFamily="serif">☥</text>
        <text x="30" y="155" textAnchor="middle" fontSize="20" fill="url(#goldGradient)" opacity="0.4" fontFamily="serif">⊙</text>
        <text x="270" y="155" textAnchor="middle" fontSize="20" fill="url(#goldGradient)" opacity="0.4" fontFamily="serif">⊙</text>
      </svg>

      {/* Padrão de símbolos egípcios */}
      <div className="symbols-pattern">
        <div className="symbol">☥</div>
        <div className="symbol">⊙</div>
        <div className="symbol">☥</div>
        <div className="symbol">⊙</div>
        <div className="symbol">☥</div>
      </div>

      {/* Partículas de luz */}
      <div className="particles-container">
        {[...Array(20)].map((_, i) => (
          <div key={i} className="particle" style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 5}s`,
            animationDuration: `${3 + Math.random() * 4}s`
          }}></div>
        ))}
      </div>

      {/* Camada de overlay */}
      <div className="overlay-layer"></div>
    </div>
  )
}

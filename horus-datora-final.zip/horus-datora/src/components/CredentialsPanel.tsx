import { useState, useEffect, useMemo } from 'react'
import { Copy, Eye, EyeOff, Download, ChevronLeft, ChevronRight, Search } from 'lucide-react'
import './CredentialsPanel.css'

interface Credential {
  login: string
  senha: string
  arquivo: string
  ips?: string[]
}

const ITEMS_PER_PAGE = 50

export default function CredentialsPanel() {
  const [credentials, setCredentials] = useState<Credential[]>([])
  const [searchNumber, setSearchNumber] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [showPasswords, setShowPasswords] = useState<{ [key: string]: boolean }>({})
  const [loading, setLoading] = useState(true)

  // Carregar dados de credenciais do JSON
  useEffect(() => {
    const loadCredentials = async () => {
      try {
        setLoading(true)
        const response = await fetch('/credentials.json')
        const data = await response.json()
        setCredentials(data)
      } catch (error) {
        console.error('Erro ao carregar credenciais:', error)
      } finally {
        setLoading(false)
      }
    }
    loadCredentials()
  }, [])

  // Filtrar credenciais baseado na busca
  const filteredCredentials = useMemo(() => {
    if (!searchNumber.trim()) {
      return credentials
    }
    return credentials.filter(cred => cred.login.includes(searchNumber))
  }, [credentials, searchNumber])

  const totalPages = Math.ceil(filteredCredentials.length / ITEMS_PER_PAGE)
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
  const endIndex = startIndex + ITEMS_PER_PAGE
  const currentCredentials = filteredCredentials.slice(startIndex, endIndex)

  // Reset para página 1 quando busca muda
  useEffect(() => {
    setCurrentPage(1)
  }, [searchNumber])

  const togglePasswordVisibility = (login: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [login]: !prev[login]
    }))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const handleExportCSV = () => {
    if (filteredCredentials.length === 0) {
      alert('Nenhuma credencial para exportar')
      return
    }

    const headers = ['Login', 'Senha', 'IP Correto', 'Arquivo', 'Todos os IPs']
    const rows = filteredCredentials.map(c => [
      c.login,
      c.senha,
      c.ips && c.ips.length > 0 ? c.ips[0] : 'N/A',
      c.arquivo,
      c.ips ? c.ips.join('; ') : ''
    ])

    const csvContent = [
      headers.map(h => `"${h}"`).join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    
    link.setAttribute('href', url)
    link.setAttribute('download', `credenciais-${new Date().toISOString().split('T')[0]}.csv`)
    link.style.visibility = 'hidden'
    
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1)
    }
  }

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1)
    }
  }

  return (
    <div className="credentials-panel-search">
      {/* Header com Busca */}
      <div className="panel-header-search">
        <div className="search-container">
          <Search size={20} className="search-icon" />
          <input
            type="text"
            placeholder="Pesquisar por número..."
            value={searchNumber}
            onChange={(e) => setSearchNumber(e.target.value)}
            className="search-input"
          />
          {searchNumber && (
            <button
              onClick={() => setSearchNumber('')}
              className="clear-search-btn"
              title="Limpar busca"
            >
              ✕
            </button>
          )}
        </div>
        <button 
          onClick={handleExportCSV}
          className="export-csv-btn"
          title="Exportar credenciais para CSV"
        >
          <Download size={20} />
          <span>Exportar CSV</span>
        </button>
      </div>

      {/* Informações de Busca */}
      <div className="search-info">
        <p>
          Total: <strong>{filteredCredentials.length}</strong> credenciais
          {searchNumber && ` (filtrado de ${credentials.length})`}
        </p>
      </div>

      {/* Tabela de Credenciais */}
      {loading ? (
        <div className="loading-state">
          <p>Carregando credenciais...</p>
        </div>
      ) : filteredCredentials.length === 0 ? (
        <div className="empty-state">
          <p>Nenhuma credencial encontrada para "{searchNumber}"</p>
        </div>
      ) : (
        <>
          <div className="table-wrapper">
            <table className="credentials-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Login</th>
                  <th>Senha</th>
                  <th>IP Correto</th>
                  <th>Arquivo</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {currentCredentials.map((cred, index) => {
                  const rowNumber = startIndex + index + 1
                  const showPassword = showPasswords[cred.login]
                  const correctIp = cred.ips && cred.ips.length > 0 ? cred.ips[0] : 'N/A'

                  return (
                    <tr key={`${cred.login}-${index}`}>
                      <td className="row-number">{rowNumber}</td>
                      <td className="login-cell">
                        <code>{cred.login}</code>
                      </td>
                      <td className="password-cell">
                        <div className="password-display">
                          <code>
                            {showPassword ? cred.senha : '•'.repeat(cred.senha.length)}
                          </code>
                          <button
                            onClick={() => togglePasswordVisibility(cred.login)}
                            className="toggle-btn"
                            title={showPassword ? 'Ocultar' : 'Mostrar'}
                          >
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                          </button>
                        </div>
                      </td>
                      <td className="ip-cell">
                        <code>{correctIp}</code>
                      </td>
                      <td className="arquivo-cell">
                        <span className="arquivo-badge">{cred.arquivo}</span>
                      </td>
                      <td className="actions-cell">
                        <button
                          onClick={() => copyToClipboard(cred.login)}
                          className="action-btn"
                          title="Copiar login"
                        >
                          <Copy size={16} />
                        </button>
                        <button
                          onClick={() => copyToClipboard(cred.senha)}
                          className="action-btn"
                          title="Copiar senha"
                        >
                          <Copy size={16} />
                        </button>
                        <button
                          onClick={() => copyToClipboard(correctIp)}
                          className="action-btn"
                          title="Copiar IP"
                        >
                          <Copy size={16} />
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Paginação */}
          {totalPages > 1 && (
            <>
              <div className="pagination">
                <button
                  onClick={goToPreviousPage}
                  disabled={currentPage === 1}
                  className="pagination-btn"
                >
                  <ChevronLeft size={20} />
                </button>
                <span className="page-info">
                  Página <strong>{currentPage}</strong> de <strong>{totalPages}</strong>
                </span>
                <button
                  onClick={goToNextPage}
                  disabled={currentPage === totalPages}
                  className="pagination-btn"
                >
                  <ChevronRight size={20} />
                </button>
              </div>

              {/* Informações de Paginação */}
              <div className="pagination-info">
                <p>
                  Mostrando <strong>{startIndex + 1}</strong> a <strong>{Math.min(endIndex, filteredCredentials.length)}</strong> de <strong>{filteredCredentials.length}</strong> credenciais
                </p>
              </div>
            </>
          )}
        </>
      )}
    </div>
  )
}
